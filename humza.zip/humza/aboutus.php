<?php include('header.php') ?>
<?php include('config/database.php') ?>
<html>
<style>
    .aboutus_Main {
        width: 100%;
        height: 500px;
        background-image: url("images/about.jpg");
        background-repeat: no-repeat;
        background-size: cover;
        text-align: center;
        line-height: 580px;

    }

    .user_Img {
        border-radius: 300px;
        width: 200px;
        height: 200px;
    }

    @media screen and (min-width: 700px) {
        .user_text {
            padding-left: 150px;
            padding-right: 150px;
            padding-top: 10px;
            padding-bottom: 0px;
        }
    }

    .about_Icon {
        border-radius: 300px;
        width: 120px;
        height: 120px;
    }
</style>
<style type="text/css">
    #container {
        width: 100%;
        height: 700px;
        background-color: #E9EAEA;
        margin: 0;
        padding: 0;
    }

    h2 {
        text-align: center;
        color: chocolate;
        padding-top: 30px;
    }

    #user1,
    #user2,
    #user3 {
        width: 24%;
        height: 350px;
        border-radius: 10px;
        background-color: white;
        display: inline-block;
        margin-left: 20px;
        box-shadow: 5px 5px 5px gray;
        position: relative;
        top: 40px;
        left: 11%;
    }

    #user1_img,
    #user2_img,
    #user3_img {
        width: 110px;
        height: 110px;
        border-radius: 50%;
        margin-top: 30px
    }

    .name {
        font-size: 20px;
        font-weight: bold;
        color: darkblue;
        text-align: center;
        position: relative;
        top: 5px;
    }

    .location {
        font-size: 20px;
        font-weight: bold;
        color: darkorange;
        text-align: center;
        position: relative;
        top: -10px;
    }

    .cursor {
        font-size: 50px;
        color: palevioletred;
        margin-left: 10px;
        position: relative;
        top: -45px;
    }

    .text {
        font-size: 18px;
        color: darkslategrey;
        margin-left: 25px;
        margin-right: 7px;
        position: relative;
        top: -115px;
    }

    @media only screen and (max-width: 1200px) {

        #user1,
        #user2,
        #user3 {
            height: 350px;
        }

        #container {
            height: 740px;
        }
    }

    @media only screen and (max-width: 610px) {
        #container {
            height: 1200px;
        }

        #user1,
        #user2,
        #user3 {
            display: block;
            width: 80%;
            height: 330px;
            margin-bottom: 20px;
            margin-left: 0px !important;
        }

        .name {
            position: relative;
            top: 0px;
        }

        .location {
            position: relative;
            top: -20px;
        }

        .cursor {
            position: relative;
            top: -75px;
        }

        .text {
            position: relative;
            top: -105px;
        }
    }
</style>

<body style='background-color: #ededed;'>
    <section class="vh-100">
        <div class='aboutus_Main'>
            <p style='z-index:100;color:aliceblue;font-size:35px;text-decoration:underline'> About Us </p>
        </div>
        <!-- <div class="row" style='justify-content:center;width:100%'>
            <div class="card p-3 col-12 col-md-6 col-lg-4 text-center" style='border:none;'>
                <div class="card-img pb-3">
                    <img src='images/abouticon1.jpg' class='about_Icon'>
                </div>
                <div class="card-box">
                    <h4 class="card-title py-3 mbr-fonts-style display-5">
                        Creativity</h4>
                    <p class="mbr-text mbr-fonts-style display-7">
                        It's the ability to think outside the box. We make decisions, create something new and generate a lot of ideas.
                    </p>
                </div>
            </div>
            <div class="card p-3 col-12 col-md-6 col-lg-4 text-center" style='border:none;'>
                <div class="card-img pb-3">
                    <img src='images/abouticon2.jpg' class='about_Icon'>
                </div>
                <div class="card-box">
                    <h4 class="card-title py-3 mbr-fonts-style display-5">
                        Worldwide</h4>
                    <p class="mbr-text mbr-fonts-style display-7">
                        All sites you make with Mobirise are mobile-friendly. You don't have to create a special mobile version of your site.
                    </p>
                </div>
            </div>
            <div class="card p-3 col-12 col-md-6 col-lg-4 text-center" style='border:none;'>
                <div class="card-img pb-3">
                    <img src='images/abouticon3.jpg' class='about_Icon'>
                </div>
                <div class="card-box">
                    <h4 class="card-title py-3 mbr-fonts-style display-5">
                        Unique Styles
                    </h4>
                    <p class="mbr-text mbr-fonts-style display-7">
                        Mobirise offers many site blocks in several themes, and though these blocks are pre-made, they are flexible.
                    </p>
                </div>
            </div>
        </div> -->
    </section>
    <section class="carousel slide testimonials-slider cid-qyvf5AQs7c" id="testimonials-slider1-3" data-rv-view="767">
        <div class="container text-center" style='margin-top:100px;margin-bottom:100px;'>
            <div class="carousel slide" data-ride="carousel" role="listbox" id="testimonials-slider1-3-carousel">
                <div class="carousel-inner text-center">
                    <div class="carousel-item active">
                        <div class="user col-md-12">
                            <div class="user_image">
                                <img class='user_Img' src="images/user1.jpg" alt="" title="" media-simple="true">
                            </div>
                            <div class="user_text pb-3">
                                <p class="user_text">
                                    Good afternoon. I am very pleased with the quality of the work of your employee representing your wonderful company.
                                </p>
                            </div>
                            <div class="user_name mbr-bold pb-2 mbr-fonts-style display-7">
                                <b>Helen</b>
                            </div>
                            <div class="user_desk mbr-light mbr-fonts-style display-7">
                                DESIGNER
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="user col-md-12">
                            <div class="user_image">
                                <img class='user_Img' src="images/user2.jpg" alt="" title="" media-simple="true">
                            </div>
                            <div class="user_text pb-3">
                                <p class="user_text">
                                    All issues are resolved promptly. In communication, the employees are pleasant, helpful. Always offer new ideas, new ways to develop, improve our project.
                                </p>
                            </div>
                            <div class="user_name mbr-bold pb-2 mbr-fonts-style display-7">
                                <b>Laura</b>
                            </div>
                            <div class="user_desk mbr-light mbr-fonts-style display-7">
                                DEVELOPER
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="user col-md-12">
                            <div class="user_image">
                                <img class='user_Img' src="images/user3.jpg" alt="" title="" media-simple="true">
                            </div>
                            <div class="user_text pb-3">
                                <p class="user_text">
                                    Excellent client manager. He is always accurate, all promises are fulfilled, all questions get answers, the company presents very attentive and positive approach.
                                </p>
                            </div>
                            <div class="user_name mbr-bold pb-2 mbr-fonts-style display-7">
                                <b>Linda</b>
                            </div>
                            <div class="user_desk mbr-light mbr-fonts-style display-7">
                                DEVELOPER
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-controls">
                    <a class="carousel-control-prev" style='color:black' role="button" data-slide="prev" href="#testimonials-slider1-3-carousel">
                        <span aria-hidden="true" style='font-size:50px' class="fa fa-chevron-left "></span>
                    </a>

                    <a class="carousel-control-next" style='color:black' role="button" data-slide="next" href="#testimonials-slider1-3-carousel">
                        <span aria-hidden="true" style='font-size:50px' class="fa fa-chevron-right "></span>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- <section>
        <div id="container">
            <h2 style='color:gray'>OUR USERS STORIES FROM AROUND THE WORLD</h2>
            <div id="user1" class="text-center">
            <img id="user1_img"  src="http://img.timeinc.net/time/daily/2010/1011/poy_nomination_agassi.jpg">
                <p class="name">ROBERT STEVEN</p>
                <p class="location">NEWYORK , USA</p>
                <p class="cursor" style='visibility:hidden'> cursor</p>
                <p class="text">here testimonial testt sts s stststs s sys ys systs s ts s stst st sts sts ss st st ss . </p>
            </div>
            <div id="user2" class="text-center" href="#">
            `<img id="user2_img" src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500">
                <p class="name">EMMIE SMITH</p>
                <p class="location">LONDON , UK</p>
                <p class="cursor" style='visibility:hidden'> cursor</p>
                <p class="text">here testimonial testt sts s stststs s sys ys systs s ts s stst st sts sts ss st st ss . </p>
            </div>
            <div id="user3" class="text-center" href="#">
                <img id="user3_img" src="https://www.ebizfiling.com/wp-content/uploads/2017/12/images_20-3.jpg">
                <p class="name">DAVID MILLER</p>
                <p class="location">PARIS , GERMANY</p>
                <p class="cursor" style='visibility:hidden'> cursor</p>
                <p class="text">here testimonial testt sts s stststs s sys ys systs s ts s stst st sts sts ss st st ss . </p>
            </div>
        </div>
    </section> -->
    <section id='testinomials'>
        <div style='background-color: #ededed;padding-top:20px;padding-bottom:60px;' id="carouselMultiItemExample" class="carousel slide carousel-dark text-center" data-mdb-ride="carousel">
        <!-- Inner -->
        <div class="carousel-inner py-4">
            <!-- Single item -->
            <div class="carousel-item active">
            <div class="container">
                <div class="row">
                <div class="col-lg-4">
                    <img class=" shadow-1-strong mb-4"
                    src="images/user1.jpg" alt="avatar"
                    style="width: 150px;" />
                    <h5 class="mb-3">Anna Deynah</h5>
                    <p>UX Designer</p>
                    <p class="text-muted">
                    <i class="fa fa-quote-left pe-2"></i>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod eos id
                    officiis hic tenetur quae quaerat ad velit ab hic tenetur.
                    </p>
                    <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    </ul>
                </div>

                <div class="col-lg-4 d-none d-lg-block">
                    <img class="shadow-1-strong mb-4"
                    src="images/user2.jpg" alt="avatar"
                    style="width: 150px;" />
                    <h5 class="mb-3">John Doe</h5>
                    <p>Web Developer</p>
                    <p class="text-muted">
                    <i class="fa fa-quote-left pe-2"></i>
                    Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis tertrert
                    suscipit laboriosam, nisi ut aliquid commodi.
                    </p>
                    <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li>
                        <i class="fa fa-star-half-alt fa-sm"></i>
                    </li>
                    </ul>
                </div>

                <div class="col-lg-4 d-none d-lg-block">
                    <img class="shadow-1-strong mb-4"
                    src="images/user3.jpg" alt="avatar"
                    style="width: 150px;" />
                    <h5 class="mb-3">Maria Kate</h5>
                    <p>Photographer</p>
                    <p class="text-muted">
                    <i class="fa fa-quote-left pe-2"></i>
                    At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
                    praesentium voluptatum deleniti atque corrupti.
                    </p>
                    <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    <li><i class="fa fa-star fa-sm"></i></li>
                    </ul>
                </div>
                </div>
            </div>
            </div>

        </div>
        <!-- Inner -->
        </div>
   </section>
</body>
</html>
<?php include('footer.php') ?>