<?php include('header.php') ?>
<?php include('config/database.php')?>
<html>
<style>
    .product {
        width: 25%;
        display: flex;
        justify-content: center;
    }

    .product_Sub {
        width: 90%;
        margin-left: 5%;
        margin-top: 5%;
    }

    .categories_Btn {
        min-width: 200px;
        height: 100%;
        background-color: #f3f3f3;
        border: 1px solid lightgrey;
        text-align: center;
        outline: none !important;
        cursor: pointer;
    }

    .categories_Btn:hover{
        background-color:#ebebeb;
    }
    .head_Gap{
        margin-top: 120px;
        background-color: #fff;
        height: 30px;
    }
    .categories {
        width: 100%;
        height: 70px;
        overflow-x: scroll;
        /* margin-top: 5px; */
        display: flex;
        justify-content: center;
    }
    @media screen and (max-width: 900px) {
        .product {
            width: 33%;
            display: block;
        }
    }

    @media screen and (max-width: 500px) {
        .product {
            width: 100%;
            display: block;
        }
    }

</style>
<body>
    <div class='head_Gap'></div>
    <div class='categories'>
        <a href='<?php echo '?name=ALL'?>'><button class='categories_Btn'> <?php echo 'ALL' ?> </button></a>
        <?php if ($result2->num_rows > 0) {
            while ($row2 = $result2->fetch_assoc()) { ?>
                <a href='<?php echo '?name='.$row2['name'] ?>'><button class='categories_Btn'> <?php echo $row2['name'] ?> </button></a>
        <?php }
        } ?>
    </div>
    <div class="container" style='padding-bottom:50px'>
        <div class="row">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) { ?>
                    <div class="product">
                        <div class="product_Sub">
                            <div class="card">
                                <img src="<?php echo 'images/' . $row['image'] ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $row['name'] ?></h5>
                                    <p class="card-text"><?php echo $row['desc'] ?></p>
                                    <p class="card-text"><?php echo $row['price'] . '/- rs' ?></p>
                                    <a href="<?php echo 'https://wa.me/'.$set['no'].'/?text='.$set['msg'].' ( '.$row['name'].' )' ?>" class="btn btn-dark">Book Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } ?>
        </div>
    </div>
</body>
</html>
<?php include('footer.php');?>
