<?php include('database.php')?>
<?php
$conn = new mysqli($servername, $username, $password, $dbname);
session_start();
$name =  $_POST['name'];
$mail = $_POST['mail'];
$subject = $_POST['subject'];
$msg = $_POST['msg'];
$sql3 = "INSERT INTO contact (name,mail,subject,msg) VALUES ('$name','$mail','$subject','$msg')";

if ($conn->query($sql3) === TRUE) {
   echo "details sent";
}
mysqli_close($conn);
?>