<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tailor";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql2 = "Select categories.name FROM categories JOIN product ON categories.name=product.category GROUP BY categories.name";
$result2 = $conn->query($sql2);

if(isset($_GET['name']) && $_GET['name'] != 'ALL')
{
    $selectedcat = $_GET['name'];
    $sql = "Select * FROM product WHERE category='".$selectedcat."'";

}
elseif(isset($_GET['name']) && $_GET['name'] == 'ALL')
{
    $sql = "Select * FROM product";
}
else
{
    $firstitem = "Select name FROM categories Limit 1";
    $selectedcat = $conn->query($firstitem);
    if ($selectedcat->num_rows > 0) {
        $selectedcat = $selectedcat->fetch_assoc();
        $selectedcat = $selectedcat['name'];
    }
    $sql = "Select * FROM product WHERE category='".$selectedcat."'";
}

$settings = "Select * FROM setting Limit 1";
$set = $conn->query($settings);
$set = $set->fetch_assoc();

$services = "Select * FROM services Limit 3";
$ser = $conn->query($services);

$services2 = "Select * FROM services Limit 3,3";
$ser2 = $conn->query($services2);

$result = $conn->query($sql);

$conn->close();
?>