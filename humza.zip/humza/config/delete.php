<?php include('database.php') ?>
<?php
$conn = new mysqli($servername, $username, $password, $dbname);
$id = $_GET['id'];

$sql = "DELETE FROM orders WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    //   echo "Record deleted successfully";
    header("Location: ../myorder.php");
} else {
    echo "Error deleting record: " . $conn->error;
}
?>