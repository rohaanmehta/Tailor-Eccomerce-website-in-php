<?php include('database.php')?>
<?php 
$conn = new mysqli($servername, $username, $password, $dbname);
$order = "Select * FROM orders  WHERE id='".$_GET['id']."'";
$od = $conn->query($order);
$od = $od->fetch_assoc();

    include "../vendor/autoload.php";
    use Dompdf\Adapter\CPDF;      
    use Dompdf\Dompdf;
    use Dompdf\Exception;
    $array = array(
        'name' => 'test'
    );
    $dompdf = new Dompdf();
    $fileContent ='
    <style>
    table,th,td {
        border: 1px solid grey;
        border-collapse: collapse;
        padding:10px;
    }
    th,td,tr{
        height:30px;
        padding:0px;
        margin:0px;
        color:grey;
        font-size:15px;
        padding-left:30px;
    }
    p{
        margin-bottom:0px;
        margin-top:0px;
    }
    .lefttd{
        width:30%;
    }
    </style>
    <div style="width:100%;display:flex;justify-content:center;text-align:center;margin-top:-40px">
    <h2 style="color:grey;">'.$set['company'].'</h2>
    <table class="table" style="width:100%;margin-left:0%">
        <tbody>
            <tr><td class="lefttd"><p>Name : </p></td><td><p>'.$od['name'].'</p></td></tr>
            <tr><td class="lefttd"><p>Number : </p></td><td><p>'.$od['number'].'</p></td></tr>
            <tr><td class="lefttd"><p>Return Date : </p></td><td><p>'.$od['returndate'].'</p></td></tr>
            <tr><td class="lefttd"><p>No of dress : </p></td><td><p>'.$od['noofdress'].'</p></td></tr>
            <tr><td class="lefttd"><p>Material : </p></td><td><p>'.$od['material'].'</p></td></tr>
            <tr><td class="lefttd"><p>Size : </p></td><td><p>'.$od['length'].'</p></td></tr>
            <tr><td style="padding-right:120px" align="right" colspan="2"><p>Sign</p></td></tr>
        </tbody>
    </table>
    </div>';

$dompdf->setpaper('a6', 'landscape');
    $dompdf->loadhtml($fileContent);
    $dompdf->render();
    $dompdf->stream("Invoice.pdf",array("Attachment" => false),$array);
    exit;
?>