<?php include('database.php') ?>
<?php

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$email = $_POST['loginemail'];
$password = $_POST['loginpassword'];
// print_r($_POST);exit;
$sql = "SELECT email,password,id FROM credentials WHERE email ='$email' AND password='$password'";

$result = $conn->query($sql);
$id = $result->fetch_assoc();

if ($result !== false && $result->num_rows > 0)
{
	 session_start();
	 $_SESSION["loggedin"] = "$email";
	 $_SESSION["id"] = $id['id'];

  	header("Location: ../dashboard.php");
}
else
{
  	header("Location: ../login.php?id=wrong");
}
?>