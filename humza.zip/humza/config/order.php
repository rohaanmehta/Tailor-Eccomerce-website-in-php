<?php include('database.php')?>
<?php
$conn = new mysqli($servername, $username, $password, $dbname);
session_start();
if(isset($_POST['autoid']))
{
   $conn = new mysqli($servername, $username, $password, $dbname);
   $id = $_POST['autoid'];
   $sql = "DELETE FROM orders WHERE id=$id";
   $conn->query($sql);
}
$name =  $_POST['name'];
$number = $_POST['number'];
$date = $_POST['date'];
$no = $_POST['no'];
$material = $_POST['material'];
$type = $_POST['type'];
$length = $_POST['size2'];
if($_POST['type'] == 'kurti'){
   $length = $_POST['size'];
   $belt = $_POST['belt'];
   $bottom = $_POST['bottom'];
   $chest = $_POST['chest'];
   $waist = '';
   $hip = '';
   $shoulder = '';
   $neck = '';
   $hand = '';
}else{
   $belt = '';
   $bottom = '';
   $chest = $_POST['chest'];
   $waist = $_POST['waist'];
   $hip = $_POST['hip'];
   $shoulder = $_POST['shoulder'];
   $neck = $_POST['neck'];
   $hand = $_POST['hand'];
}
// echo '<pre>';print_r($_POST);exit;
$id = $_SESSION["id"];
$sql3 = "INSERT INTO orders (name,number,returndate,noofdress,material,length,user,type,belt,bottom,chest,waist,shoulder,neck,hand,hipp) 
VALUES ('$name','$number','$date','$no','$material','$length','$id','$type','$belt','$bottom','$chest','$waist','$shoulder','$neck','$hand','$hip')";

if ($conn->query($sql3) === TRUE) {
   echo "order inserted";
   header("Location: ../myorder.php");
} else {
   echo "Error inserting record: " . $conn->error;
}
mysqli_close($conn);
?>