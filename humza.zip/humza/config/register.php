<?php include('database.php')?>
<?php
$conn = new mysqli($servername, $username, $password, $dbname);

$email =  $_POST['signemail'];
$password = $_POST['signpassword'];
$no = $_POST['no'];

$sql3 = "INSERT INTO credentials (email,password,number) VALUES ('$email','$password','$no')";

if ($conn->query($sql3) === TRUE) {
   // echo "New record created successfully";
   $last_id = $conn->insert_id;
   session_start();
   $_SESSION["loggedin"] = $email;
   $_SESSION["id"] = $last_id;
   header("Location: ../dashboard.php");
} else {
   echo "Error: go back and try again  " . $sql3 . "<br>" . $conn->error;
}
mysqli_close($conn);
?>