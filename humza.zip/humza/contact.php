<?php include('header.php') ?>
<?php include('config/database.php') ?>
<html>

<body style="background-color: #ededed;">
    <section class="vh-100">
        <div class="container-fluid h-custom" style='background-color: #ededed;padding-bottom:100px;min-height:100vh;margin-top:120px;padding-top:30px;background-color: #f7f4ef;'>
                <h2 class="h1-responsive font-weight-bold text-center my-4">Contact us</h2>
                <p class="text-center w-responsive mx-auto mb-5">Do you have any questions? Please do not hesitate to contact us directly. Our team will come back to you within
                    a matter of hours to help you.</p>
                <div class="row col-lg-12" style='justify-content:center;margin:0px !important'>
                    <div class="col-md-10 mb-md-0 mb-5">
                        <form action="config/contact.php" method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="md-form mb-0">
                                        <label for="name" class="">Your name</label>
                                        <input type="text" id="name" name="name" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="md-form mb-0">
                                        <label for="email" class="">Your email</label>
                                        <input type="text" id="email" name="mail" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="md-form mb-0">
                                        <label for="subject" class="">Subject</label>
                                        <input type="text" id="subject" name="subject" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="md-form">
                                        <label for="message">Your message</label>
                                        <textarea type="text" style='resize:none' id="message" name="msg" rows="2" class="form-control md-textarea"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center text-lg-start mt-2 pt-2">
                                <button type="submit" class="btn btn-dark col-lg-12" style="padding-left: 2.5rem; padding-right: 2.5rem;">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            <!-- </div> -->
    </section>
</body>
</html>
<?php include('footer.php') ?>