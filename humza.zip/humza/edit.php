<?php include('header.php');
$id = '';
if(isset($_GET['id']))
{
    $id = $_GET['id'];
}?>
<?php include('config/database.php');
    if(!isset($_SESSION['loggedin']))
    {		
        header("Location: index.php");
    }
    $conn = new mysqli($servername, $username, $password, $dbname);
    $order = "Select * FROM orders  WHERE id='".$_GET['id']."'";
    $od = $conn->query($order);
    $od = $od->fetch_assoc();
?>
<html>
<style>
    input{
        outline: none !important;
        box-shadow: none !important;
    }
    input::placeholder{
        color: #b5b5b5 !important;
    }
    .form-control:focus{
        border: 1px solid #b5b5b5 !important;
    }
    select {
      height: 35px;
      border: 0;
      outline: 1px solid #ccc;
    }
    #left_menu_Button{
        width: 170px;
        height: 40px;
        background-color: #d1d1d1;
        border: 1px solid #a5a5a5;
        font-size: 20px;
        cursor: pointer;
        margin-top: -10px;
        margin-bottom: 10px;
        outline: none;
    }
    #link{
        text-decoration: none;
        color: grey;
    }
    .ordertable{
        padding-left:300px;
        padding-bottom:50px;
        margin-top:140px;
        padding-top:30px;
        background-color: #f7f4ef;
    }
    @media screen and (max-width: 760px) {
        .ordertable{
            padding-left:0px;
        }
    }
    </style>
<body>
    <section class="vh-100">
        <div class="container-fluid h-custom" style='padding-bottom:50px;margin-top:140px;padding-top:30px;background-color: #f7f4ef;'>
            <div class="row d-flex justify-content-center">
                <!-- <div class="col-md-9 col-lg-6 col-xl-5" style='text-align:center'>
                    <img src="images/service1.jpg" class="img-fluid" alt="Sample image">
                </div> -->
                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                    <form action='config/order.php' method='post'>
                        <div class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
                            <h3>Edit Order</h3><br><br>
                        </div>
                        <!-- Email input -->
                        <div class="form-outline mb-3">
                            <label for="exampleInputEmail1" style="margin-top:-5px;margin-bottom: 0px;">Name</label>
                            <input type="text" id="name" name='name' class="form-control form-control" value='<?php echo $od['name'] ?>' />
                        </div>
                        <div class="form-outline mb-3">
                            <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Number</label>
                            <input type="text" id="number" name='number' class="form-control form-control"  value='<?php echo $od['number'] ?>' />
                        </div>
                        <div class="form-outline mb-3">
                            <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Return date</label>
                            <input type="date" id="date" name='date' class="form-control form-control"  value='<?php echo date('Y-m-d',strtotime( $od['returndate'] ))?>'/>
                        </div>
                        <div class="form-outline mb-3">
                            <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">No of dress</label>
                            <input type="text" id="no" name='no' class="form-control form-control"  value='<?php echo $od['noofdress'] ?>'/>
                        </div>
                        <div class="form-outline mb-3">
                            <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Type</label>
                            <select name='type' id='type' onchange=change(); class="form-select col-lg">
                                <option value='pant'>Pant</option>
                                <option value='kurti'>Kurti</option>
                            </select>                        
                        </div>       
                        <div class='pant' style='display:none'>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Size</label>
                                <input type="text" id="size2" name='size2' class="form-control form-control"  value='<?php echo $od['length'] ?>' />
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Chest</label>
                                <input type="text" id="chest" name='chest' class="form-control form-control"  value='<?php echo $od['chest'] ?>'/>
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Waist</label>
                                <input type="text" id="waist" name='waist' class="form-control form-control"  value='<?php echo $od['waist'] ?>' />
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Hip</label>
                                <input type="text" id="hip" name='hip' class="form-control form-control"  value='<?php echo $od['hipp'] ?>'/>
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Shoulder</label>
                                <input type="text" id="shoulder" name='shoulder' class="form-control form-control"  value='<?php echo $od['shoulder'] ?>' />
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Neck</label>
                                <input type="text" id="neck" name='neck' class="form-control form-control"  value='<?php echo $od['neck'] ?>'/>
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Hand</label>
                                <input type="text" id="hand" name='hand' class="form-control form-control"  value='<?php echo $od['hand'] ?>' />
                            </div>
                        </div>    
                        <div class='kurti'>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Size</label>
                                <input type="text" id="size" name='size' class="form-control form-control"  value='<?php echo $od['length'] ?>' />
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Belt</label>
                                <input type="text" id="belt" name='belt' class="form-control form-control"  value='<?php echo $od['belt'] ?>' />
                            </div>
                            <div class="form-outline mb-3">
                                <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Bottom</label>
                                <input type="text" id="bottom" name='bottom' class="form-control form-control"  value='<?php echo $od['bottom'] ?>'/>
                            </div>
                        </div> 
                        <div class="form-outline mb-3">
                            <label for="exampleInputEmail1" style="margin-top:-10px;margin-bottom: 0px;">Material</label>
                            <select id='select' name='material' class="form-select col-lg">
                                <option>SILK</option>
                                <option>COTTON</option>
                                <option>CHIFFON</option>
                                <option>FABRICS</option>
                                <option>NATURAL</option>
                                <option>SYNTHETIC</option>
                            </select>                        
                        </div>
                        <div class="text-center text-lg-start mt-2 pt-2">
                            <button type="submit" class="col-lg-12 btn btn-dark btn" style="padding-left: 2.5rem; padding-right: 2.5rem;">Save </button>
                        </div>
                        <input type='hidden' name='autoid' id='autoid' value='<?php echo $od['id']; ?>'/>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
<script>
$( document ).ready(function() {
    var option = '<?php echo $od['material']?>';
    $('#select').val(option);

    var option2 = '<?php echo $od['type']?>';
    $('#type').val(option2);
    change(option2);
});

function change(){
    if($('#type').val() != 'kurti'){
        $('.kurti').css('display','block');
        $('.pant').css('display','none');
    }else{
        $('.pant').css('display','block');
        $('.kurti').css('display','none');
    }
}
</script>
</html>
<?php include('footer.php');?>
