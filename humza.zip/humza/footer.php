<?php include('config/database.php');?>
<html>
<head>
    <link rel="stylesheet" href="css/footer.css" />
</head>
<body>
<div class="footer navbar-inverse navbar-fixed-bottom d-flex flex-column flex-md-row text-center text-md-start justify-content-between py-4 px-4 px-xl-5 footbar">
    <div class="text-white mb-3 mb-md-0">
        Copyright © 2021. All rights reserved.
    </div>
    <div style='padding-bottom:10px;'>   
        <?php if(!isset($_SESSION['loggedin'])) { ?>
            <a href="index.php" style='color:gray' id="link"> HOME |</a>
            <a href="catalogue.php"  style='color:gray' id="link"> CATALOGUE |</a>
            <a href="aboutus.php"  style='color:gray' id="link"> ABOUT US | </a>
            <a href="contact.php"  style='color:gray' id="link"> CONTACT | </a>
            <a href="register.php" style="color:gray;" id="link"> TAILOR LOGIN </a>
        <?php } else{?>
                <a href="dashboard.php" id="link"> DASHBOARD   |</a>
                <a href="myorder.php" id="link"> MY ORDERS   | </a>
                <a href="config/logout.php"id="link"> LOGOUT  </a>
            <?php } ?>
    </div>
    <div>
        <a href="<?php echo $set['instalink']?>">
            <i class="fa fa-instagram" style="font-size:25px; margin-left:15px;color:white;"></i>
        </a>
        <a href="<?php echo $set['fblink']?>">
            <i class="fa fa-facebook-square" style="font-size:25px; margin-left:15px;color:white;"></i>
        </a>
        <a href="<?php echo $set['maillink']?>">
            <i class="fa fa-envelope" style="font-size:25px; margin-left:15px;color:white;"></i>
        </a>
        <a href="<?php echo $set['whatsapplink']?>">
            <i class="fa fa-whatsapp" style="font-size:25px; margin-left:15px;color:white;"></i>
        </a>
    </div>
</div>