<?php include('config/database.php')?>
<?php 
    session_start();
?>
<html>
<head>
    <link rel="stylesheet" href="css/headerstyle.css" />
    <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <div style='background-color:#111;width:100%;height:120px;margin-bottom:-150px'>
        <p>aa</p>
    </div>
    <div id="navbar">
        <a href="http://localhost/humza" id="logo"><?php echo $set['company'] ?></a>
        <!-- <img src='images/logo.png' class='logo' /> -->
        <div style='color:#fff;text-align:end;'><span id='user'> <?php if(isset($_SESSION['loggedin'])){ echo 'welcome '.$_SESSION['loggedin'];}?></span>
        <div id="navbar-right">  
            <?php 
            if(!isset($_SESSION['loggedin'])) { 
                echo '<a href="index.php" id="link"> HOME </a>';
                echo '<a href="catalogue.php" id="link"> CATALOGUE </a>';
                echo '<a href="aboutus.php" id="link"> ABOUT US </a>';
                echo '<a href="contact.php" id="link"> CONTACT </a>';
                echo '<a href="register.php" style="color:#ffc300;" id="link"> TAILOR LOGIN </a>';
            }
            else
            {
                // echo '<a href="dashboard.php" id="link"> DASHBOARD </a>';
                // echo '<a href="myorder.php" id="link"> MY ORDERS </a>';
                echo '<a href="config/logout.php" id="link"> LOGOUT </a>';
            }
            ?>
        </div>
        </div>
        <div class='noborder'>
            <a href="javascript:void(0);"  class='mobile_Icon' onclick="openNav()">
                <i id ='ic' class="fa fa-bars"></i>
            </a> 
        </div>
    </div>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" id='closebtn' onclick="closeNav()">&times;</a>
        <?php 
            if(!isset($_SESSION['loggedin'])) { 
                echo '<a href="index.php" id="link"> HOME </a>';
                echo '<a href="catalogue.php" id="link"> CATALOGUE </a>';
                echo '<a href="aboutus.php" id="link"> ABOUT US </a>';
                echo '<a href="contact.php" id="link"> CONTACT </a>';
                echo '<a href="register.php" style="color:#ffc300;" id="link"> TAILOR LOGIN </a>';
            }
            else
            {
                echo '<a href="dashboard.php" id="link"> DASHBOARD </a>';
                echo '<a href="myorder.php" id="link"> MY ORDERS </a>';
                echo '<a href="config/logout.php" id="link"> LOGOUT </a>';
            }
            ?>
    </div>
    <?php 
    if(isset($_SESSION['loggedin'])) { ?>
        <div id='leftmenu'>
            <button id="left_menu_Button" style='width:100%;height:50px;background-color:#d1d1d1'><a id='link' href="dashboard.php" id="link"> DASHBOARD </a></button>
            <button id="left_menu_Button" style='width:100%;height:50px;background-color:#d1d1d1' style='margin-left:-10px'><a id='link' href="myorder.php" id="link"> MY ORDERS </a></button>
        </div>
    <?php } ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        window.onscroll = function() {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
                document.getElementById("navbar").style.padding = "0px 10px 0px 10px";
                document.getElementById("user").style.display = "none";
                document.getElementById("logo").style.margin = "0px 0px 0px 0px";
            } else {
                document.getElementById("navbar").style.padding = "20px 10px 20px 10px";
                document.getElementById("user").style.display = "block";
                document.getElementById("logo").style.margin = "-3px 0px 0px 0px";
            }
        }

        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }

        $('body').click(function(evnt) {
        if (evnt.target.id != "closebtn" && evnt.target.id != "mySidenav" && evnt.target.id != "ic") {
            closeNav();
        }
    });
    </script>
</body>

</html>