<?php include('config/database.php')?>
<?php include('header.php') ?>
<html>

<head>

</head>
<style>
    /* .bgimg{
        background-image:url('https://media.sproutsocial.com/uploads/2017/02/10x-featured-social-media-image-size.png');
        position: absolute;
        width:80%;
        height: 76% ;
        opacity: 0.18;
        background-repeat: no-repeat;
        background-size: cover;
        background-image: url('https://c1.wallpaperflare.com/preview/863/805/315/thread-sewing-colorful-sew.jpg');
    } */

    .bgimg{
      content: "";
      background-image: url('https://c1.wallpaperflare.com/preview/863/805/315/thread-sewing-colorful-sew.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      /* position: absolute; */
      /* top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px; */
      opacity: 0.1;
}
.bgimg::before { 
    position: relative; 
    height: 100vh;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-image: url('https://placekitten.com/1200/800');
    background-size: cover;
}
.sec{
    background-color: #f1f3f3;
    /* padding-bottom: 40px; */
    height:80%;
    border-radius: 10px;
    padding: 20px;
}
.sec2{
    margin-top: -60px !important;
    margin-bottom: 40px !important;
}
</style>
<body style='background-color: #ededed;'>
    <section id='hero'>
        <div id="carouselExampleIndicators" style='margin-top:120px' class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="carousel-caption d-none d-md-block">
                        <h5> Custom tailoring at your doorstep </h5>
                        <p> Your Design we deliver </p>
                    </div>
                    <img class="d-block w-100" height='500' src="images/carousel2.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                    <div class="carousel-caption d-none d-md-block">
                        <h5> Custom tailoring at your doorstep </h5>
                        <p> Your Design we deliver </p>
                    </div>
                    <img class="d-block w-100" height='500' src="images/carousel3.jpg" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <div class="carousel-caption d-none d-md-block">
                        <h5> Custom tailoring at your doorstep </h5>
                        <p> Your Design we deliver </p>
                    </div>
                    <img class="d-block w-100" height='500' src="images/carousel1.jpg" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </section>
    <section id='body'>
    <div>
        <!-- <img class='bgimg'src='https://c1.wallpaperflare.com/preview/863/805/315/thread-sewing-colorful-sew.jpg'/> -->
        <div class="container " style=''>
            <!-- <img class='bgimg'src='https://c1.wallpaperflare.com/preview/863/805/315/thread-sewing-colorful-sew.jpg'/> -->
            <div class="row">
                <div class='body_Center'>
                    <h2 style='margin-top:80px'>How Does The Tailor Work ?</h2>
                </div>
                <div class='body_Center'>
                    <h5 style='margin-top:10px;color:#555555'>It’s simple, affordable and risk free.</h5>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4 sec2">
                    <div class='sec' style='text-align:center;margin-top:100px'>
                        <img class='body_Content_Box_Img' src='images/bodycontent1.png' />
                        <h3>Pick</h3>
                        <h5 style='color:#a1a1a1''>Once you book the appointment, our representative will call you and a time will be scheduled for the pickup, then tailor will take measurements and pick your fabric.</h5>
                    </div>   
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4 sec2" style='' >
                    <div class='sec' style=' text-align:center;margin-top:100px;'>
                            <img class='body_Content_Box_Img' src='images/bodycontent2.png' />
                            <h3>Stitch</h3>
                            <h5 style='color:#a1a1a1''>Outfit will be stitched under experts guidance.</h5>
                    </div>   
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4 sec2" style=''>
                    <div class='sec' style=' text-align:center;margin-top:100px;'>
                        <img class='body_Content_Box_Img' src='images/bodycontent3.png' />
                        <h3>Deliver</h3>
                        <h5 style='color:#a1a1a1''>After stitching the outfit will be delivered at your place, and if there will be any alteration required, the tailor will redo again and redeliver it at your place.</h5>
                    </div>  
                </div>
            </div>
        </div>
    </div>
    </section>
    <section id=' service'>
        <div style='margin-top:20px;padding-bottom:60px;width:100%;background-color:#f7f4ef' ;>
            <div class="container" style='margin-bottom:30px'>
                <div class="row">
                    <div class='body_Center'>
                        <h2 style='margin-top:80px'>Our Services</h2>
                    </div>
                    <div class='body_Center'>
                        <h5 style='margin-top:10px;margin-bottom:100px;color:#555555'>From everyday clothing such as jeans to men suits or dresses, we modify and <br> tailor as per your requests with great results.</h5>
                    </div>
                    <?php foreach($ser as $row)
                    {   
                        echo '<div class="col-xs-12 col-sm-4 col-md-4">';
                        echo '<div style="text-align:center;margin-top:0px">';
                        echo '<div class="service_Box">';
                        echo '<img src="'.$row['image'].'" class="service_Box_Image" />';
                        echo '<p style="color:#000;width:100%;font-size:20px;margin:auto;">'.$row['name'].'</hp>';
                        echo '</div></div></div>';
                    }?>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <?php foreach($ser2 as $row2)
                    {   
                        echo '<div class="col-xs-12 col-sm-4 col-md-4">';
                        echo '<div style="text-align:center;margin-top:0px">';
                        echo '<div class="service_Box">';
                        echo '<img src="'.$row2['image'].'" class="service_Box_Image" />';
                        echo '<p style="color:#000;width:100%;font-size:20px;margin:auto;">'.$row2['name'].'</hp>';
                        echo '</div></div></div>';
                    }?>
                </div>
            </div>
        </div>
    </section>
    <section id='bookappointment'>
        <div class="appointment">
            <div class="row" style='margin:0px !important'>
                <div class="col-xs-12 col-sm-7 col-md-7" style='padding-left:50px'>
                    <div class='appointment_Txt'>
                        <h1>Your Design, We Deliver</h1>
                        <h6>Providing you with a maximum level of comfort & confidence in every suit!</h6>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div style='text-align:center;margin-top:0px'>
                    <a href="<?php echo 'https://wa.me/'.$set['no'].'/?text= I need to book an appointment'?>">
                        <button class='appointment_Btn'> Book Appointment</button>
                    </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id='describtion'>
        <div class="row" style='margin:0px !important;text-align:center'>
            <div class="col-xs-12 col-sm-12 col-md-12" style='padding-top:70px'>
                <h1>Why Choose us ?</h1>
            </div>
        </div>
        <div class="row" style='margin:0px !important;padding:40px;padding-bottom:100px'>
            <div class="col-xs-12 col-sm-6 col-md-6">
                <div class='appointment_Txt'>
                    <h6 style='line-height: 1.5;color:#555555' >Tailor junction is a online boutique which take care of all stitching requirements of men , women and kids, be it alterations or fresh stitching or customisation or redo of old saree. We provide doorstep services without any minimum price requirements. We have wide range of fabrics and accessories. Our motive is to make relations not customers. So until and unless our customers are not satisfied with our work, we keep on giving them services. Our model of tailoring is not like others who work only for money, we give value to your money and time.</h6>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6">
                <div class='appointment_Txt'>
                    <h6 style='line-height: 1.5;color:#555555'>Tailor junction is a online boutique which take care of all stitching requirements of men , women and kids, be it alterations or fresh stitching or customisation or redo of old saree. We provide doorstep services without any minimum price requirements. We have wide range of fabrics and accessories. Our motive is to make relations not customers. So until and unless our customers are not satisfied with our work, we keep on giving them services. Our model of tailoring is not like others who work only for money, we give value to your money and time.</h6>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
<?php include('footer.php');?>
