<?php include('header.php');
$id = '';
if(isset($_GET['id']))
{
    $id = $_GET['id'];
}?>
<?php include('config/database.php');
    if(!isset($_SESSION['loggedin']))
    {		
        header("Location: index.php");
    }
    $conn = new mysqli($servername, $username, $password, $dbname);
    $id = $_SESSION['id'];
    $myordersql = "Select * FROM orders WHERE user ='$id'";
    $myorder = $conn->query($myordersql);

?>
<html>
<style>
    #left_menu_Button{
        width: 170px;
        height: 40px;
        background-color: #d1d1d1;
        border: 1px solid #a5a5a5;
        font-size: 20px;
        cursor: pointer;
        margin-top: -10px;
        margin-bottom: 10px;
        outline: none;
    }
    #link{
        text-decoration: none;
        color: grey;
    }
    .ordertable{
        padding-left:300px;
        padding-bottom:50px;
        margin-top:140px;
        padding-top:30px;
        background-color: #f7f4ef;
    }
    @media screen and (max-width: 760px) {
        .ordertable{
            padding-left:0px;
        }
    }
    </style>
    <head>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    </head>
<body>
    <section class="vh-100">
        <div class="container-fluid h-custom ordertable">   
        <div class="table-responsive-sm" style='margin-top:20px;border:1px solid #dee2e6;height:700px;overflow-y:scroll'>
                <table id='datatable' class=" table  table-striped table-hover">
                    <thead class='thead-dark' style='position:sticky;top:0;'>
                        <tr>
                        <th scope="col">No</th>
                        <th scope="col">Name</th>
                        <th scope="col">Number</th>
                        <th scope="col">Return date</th>
                        <th scope="col">No of dress</th>
                        <th scope="col">Material</th>
                        <th scope="col">Size</th>
                        <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;foreach($myorder as $row)
                        {
                            ?>
                        <tr>
                            <td scope="row"><?php echo $i;?></td>
                            <td><?php echo $row['name'] ;?></td>
                            <td><?php echo $row['number'] ;?></td>
                            <td><?php echo $row['returndate'] ;?></td>
                            <td><?php echo $row['noofdress'] ;?></td>
                            <td><?php echo $row['material'] ;?></td>
                            <td><?php echo $row['length'] ;?></td>
                            <td>
                                <a href='<?php echo 'edit.php?id='.$row['id']?>'><i class="fa fa-edit" style="font-size:25px; margin-left:15px;color:blue;"></i></a>
                                <a href='<?php echo 'config/delete.php?id='.$row['id']?>'><i class="fa fa-trash" style="font-size:25px; margin-left:15px;color:red;"></i></a>
                                <a href='<?php echo 'config/dompdf.php/?id='.$row['id']?>'><i class="fa fa-print" style="font-size:25px; margin-left:15px;color:green;"></i></a>
                            </td>
                        </tr>
                        <?php $i++; } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <script>
    $(document).ready( function () {
        $('#datatable').DataTable();
    });
    </script>
</body>
</html>
<?php include('footer.php');?>
