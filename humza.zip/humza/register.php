<?php include('header.php');
$id = '';
if(isset($_GET['id']))
{
    $id = $_GET['id'];
}?>
<html>
<style>
    input{
        outline: none !important;
        box-shadow: none !important;
    }
    </style>
<body>
    <section class="vh-100">
        <div class="container-fluid h-custom" style='padding-bottom:50px;margin-top:120px;padding-top:30px;background-color: #f7f4ef;'>
            <div class="row d-flex justify-content-center">
                <div class="col-md-9 col-lg-6 col-xl-5" style='text-align:center'>
                    <img src="images/service1.jpg" class="img-fluid" alt="Sample image">
                </div>
                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1"><br><br>
                    <form action='config/register.php' method='post'>
                        <div class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
                            <h3>Sign up</h3><br><br>
                        </div>
                        <!-- Email input -->
                        <div class="form-outline mb-3">
                            <input type="email" id="signemail" name='signemail' class="form-control form-control" placeholder="Email Address" />
                        </div>
                        <div class="form-outline mb-3">
                            <input type="text" id="no" name='no' class="form-control form-control" placeholder="Phone Number" />
                        </div>
                        <!-- Password input -->
                        <div class="form-outline mb-3">
                            <input type="password" id="signpassword" name='signpassword' class="form-control form-control" placeholder="Password" />
                        </div>

                        <div class="text-center text-lg-start mt-2 pt-2">
                            <button type="submit" class="col-lg-12 btn btn-dark btn" style="padding-left: 2.5rem; padding-right: 2.5rem;">Sign up</button>
                        </div>
                    </form>
                    <div style='width:100%;text-align:center'><a href='login.php'> Already a user ? Sign In here</a></div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
<?php include('footer.php');?>
